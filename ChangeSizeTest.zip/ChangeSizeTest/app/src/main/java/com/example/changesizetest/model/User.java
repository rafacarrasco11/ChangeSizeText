package com.example.changesizetest.model;

/**
 * Clase que guarda la informacion del login del usuario
 */
public class User {
    private String name;
    private String user;

    public User(String name, String user) {
        this.name = name;
        this.user = user;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", user='" + user + '\'' +
                '}';
    }
}
